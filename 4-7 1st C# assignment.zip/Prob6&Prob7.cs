using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;
    using System.Collections.Generic;
    class Student
    {
        static void getStudentsList(string[] file)
        {
            int averageScore;
            int maximumAvgScore = Int32.MinValue;
            List<string> names = new List<string>();
            for (int i = 0; i < file.Length; i += 4)
            {
                averageScore = (Int32.Parse(file[i + 1]) +
                            Int32.Parse(file[i + 2]) +
                        Int32.Parse(file[i + 3])) / 3;

                if (averageScore > maximumAvgScore)
                {
                    maximumAvgScore = averageScore;
                    names.Clear();
                    names.Add(file[i]);
                }

                else if (averageScore == maximumAvgScore)
                    names.Add(file[i]);
            }


            for (int i = 0; i < names.Count; i++)
            {
                Console.Write(names[i] + " ");
            }

            Console.WriteLine(maximumAvgScore);
        }

        public static void Main()
        {
            string[] file = { "Dinesh", "100", "80", "45", "Satish", "95", "50", "88", "Smith", "97", "65", "93", "sandy", "67", "79", "65" };
            getStudentsList(file);
        }
    }

}







7TH QUESTION


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;
    public class SwappingOfTwoNumbers
    {
        public static void Main(string[] args)
        {
            int n1, n2, temp;
            Console.Write("\nInput the First Number : ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("\nInput the Second Number : ");
            n2 = int.Parse(Console.ReadLine());
            temp = n1;
            n1 = n2;
            n2 = temp;
            Console.Write("\nAfter Swapping Of Two Numbers : ");
            Console.Write("\nThe First Number : " + n1);
            Console.Write("\nThe Second Number : " + n2);
            Console.Read();
        }
    }

}

