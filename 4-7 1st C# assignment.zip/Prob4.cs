﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace ConsoleApp14
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                //Reading the First Number
                Console.Write("Enter the First Number: ");
                int a = Convert.ToInt16(Console.ReadLine());
                //Reading Second Number  
                Console.Write("Enter the Second Number: ");
                int b = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("1.Addition");
                Console.WriteLine("2.Subtraction");
                Console.WriteLine("3.Divsion");
                Console.WriteLine("4.Multiplication");
                //Reading a Choice  
                int c0 = Convert.ToInt16(Console.ReadLine());
                int c1 = Convert.ToInt16(Console.ReadLine());
                int c2 = Convert.ToInt16(Console.ReadLine());
                int c3 = Convert.ToInt16(Console.ReadLine());
              
                switch (c0)
                {
                    case 1:
                        Console.WriteLine("Addition Of Two Numbers : " + (a + b));
                        break; }
                switch (c1)
                {
                    case 2:
                        Console.WriteLine("Subtraction Of Two Numbers : " + (a - b));
                        break;
                }
                switch (c2)
                {
                    case 3:
                        Console.WriteLine("Division Of Two Numbers : " + (a / b));
                        break;
                }
                switch (c3)
                {
                    case 4:
                        Console.WriteLine("Multiplicaion Of Two Numbers : " + (a * b));
                        break;
                    default:
                        Console.WriteLine("Choose Only c0 To c3 ");
                        break;
                }
                Console.ReadLine();

            }
        }
    }
}
